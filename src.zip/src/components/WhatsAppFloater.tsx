'use client'
export default function WhatsAppFloater({ phone = '9891234195', text = 'Hi! I am interested.' }:{ phone?: string; text?: string }) {
  const digits = phone.replace(/\D/g,'')
  const href = `https://wa.me/91${digits.startsWith('91') ? digits.slice(2) : digits}?text=${encodeURIComponent(text)}`
  return (
    <a href={href} target="_blank" rel="noopener noreferrer"
       className="fixed bottom-5 right-5 z-50 rounded-full shadow-lg grid place-items-center"
       aria-label="WhatsApp Chat"
       style={{ width: 56, height: 56, background: '#25D366', boxShadow: '0 8px 30px rgba(37,211,102,.35)' }}>
      <svg viewBox="0 0 448 512" width="26" height="26" aria-hidden>
        <path fill="#fff" d="M380.9 97.1C339 55.1 283.2 32 224.4 32h-.1C106.1 32 10.7 127.4 10.7 245.7c0 37.6 9.8 74.3 28.5 106.6L0 480l131.9-38.8c30.5 16.7 64.8 25.5 100 25.5h.1c118.2 0 213.6-95.4 213.6-213.7 0-58.5-23-113.6-64.7-156zm-156.6 320h-.1c-30.4 0-60.2-8.1-86.2-23.5l-6.2-3.7-78.3 23 23.4-76.2-4-6.4c-17.7-28.4-27-61.2-27-94.7 0-98.4 80.1-178.5 178.6-178.5h.1c47.7 0 92.6 18.6 126.3 52.4 33.7 33.8 52.3 78.7 52.3 126.4 0 98.5-80.1 178.6-178.9 178.6zm99.3-134.9c-5.4-2.7-31.8-15.7-36.7-17.5-4.9-1.8-8.5-2.7-12.1 2.7-3.6 5.4-13.8 17.5-16.9 21.1-3.1 3.6-6.2 4.1-11.6 1.4-31.5-15.7-52.1-28.1-72.8-63.8-5.5-9.5 5.5-8.8 15.7-29.5 1.7-3.6.9-6.8-.5-9.5-1.4-2.7-12.1-29.2-16.6-40-4.4-10.6-8.9-9.2-12.1-9.4-3.1-.2-6.8-.2-10.5-.2s-9.5 1.4-14.5 6.8c-5 5.4-19.1 18.7-19.1 45.7s19.6 53 22.4 56.6c2.7 3.6 38.2 58.3 92.6 81.8 34.6 15 48.1 16.3 65.3 13.7 10.5-1.6 31.8-13 36.3-25.5 4.5-12.5 4.5-23.2 3.1-25.5-1.3-2.3-4.9-3.7-10.3-6.4z"/>
      </svg>
    </a>
  )
}
