// src/components/PopupOnIdle.tsx
'use client'

export default function PopupOnIdle() {
  // disabled globally
  return null
}
