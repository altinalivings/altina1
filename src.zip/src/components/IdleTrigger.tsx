// src/components/IdleTrigger.tsx
'use client'
export default function IdleTrigger() {
  // disabled globally
  return null
}
