// AUTO-GENERATED FILE PLACEHOLDER
// If you haven't generated icons yet, this prevents build failures.
// Run: node scripts/generateAmenityIcons.mjs to populate this file.

const AMENITY_ICONS: Record<string, string> = {};
export default AMENITY_ICONS;
